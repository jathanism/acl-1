"""
Built-in Loader classes for populating `~trigger.netdevices.NetDevices` with
`~trigger.netdevices.NetDevice` objects.

By default, Trigger provides filesystem-based data loaders.
"""
