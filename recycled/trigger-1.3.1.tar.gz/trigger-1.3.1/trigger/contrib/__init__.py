"""
trigger.contrib
~~~~~~~~~~~~~~~

Extra, optional tools that solve common problems, extend, or modify core
functionality.
"""
