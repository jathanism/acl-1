Contributors
============

The following people have contributed to Trigger at some point during its
lifetime: 

- `Jathan McCollum <https://github.com/jathanism>`_
- Eileen Tschetter
- `Mark Ellzey Thomas <https://github.com/ellzey>`_
- Michael Shields
- Jeff Sullivan (for the best error message ever)
- `Nick Sinopoli <https://github.com/NSinopoli>`_ (for graciously giving us the
  name Trigger!)
- `Jason Long <https://github.com/sh0x>`_
- `Michael Harding <https://github.com/mvh>`_
- William White
- `Allan Feid <https://github.com/crazed>`_
