:mod:`trigger.exceptions` --- Trigger's Exceptions
==================================================

.. automodule:: trigger.exceptions
   :members:
