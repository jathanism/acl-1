:mod:`trigger.netdevices` --- Network device metadata library
=============================================================

.. automodule:: trigger.netdevices
   :members: device_match, NetDevice, Vendor

.. autoclass:: NetDevices
    :members: _actual
