:mod:`trigger.rancid` --- RANCID Compatibility Library
======================================================

.. automodule:: trigger.rancid
   :members:
