:mod:`trigger.cmds` --- Command execution library
=================================================

.. automodule:: trigger.cmds
   :members:
