:mod:`trigger.tacacsrc` --- Network credentials library
=======================================================

.. automodule:: trigger.tacacsrc
   :members:
