:mod:`trigger.changemgmt` --- Change management library
=======================================================

.. automodule:: trigger.changemgmt
   :members:
