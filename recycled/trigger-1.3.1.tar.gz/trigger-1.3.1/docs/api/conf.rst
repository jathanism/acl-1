:mod:`trigger.conf` --- Configuration & Settings module
=======================================================

.. automodule:: trigger.conf
   :members:
