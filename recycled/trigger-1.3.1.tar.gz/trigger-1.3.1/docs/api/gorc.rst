:mod:`trigger.gorc` --- Determine commands to run upon login
============================================================

.. automodule:: trigger.gorc
   :members:

