:mod:`trigger.netscreen` --- Juniper NetScreen firewall parser
==============================================================

.. automodule:: trigger.netscreen
   :members:
