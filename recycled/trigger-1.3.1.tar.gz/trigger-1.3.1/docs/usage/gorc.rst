====================================================
Determine commands to run upon login using ``.gorc``
====================================================

.. automodule:: trigger.gorc

For detailed instructions on how to create a ``.gorc``, please see :ref:`gorc-doc`.
