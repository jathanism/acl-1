#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Converts old .tacacsrc to new .tacacsrc.gpg.

from trigger.tacacsrc import convert_tacacsrc

if __name__ == '__main__':
    convert_tacacsrc()
